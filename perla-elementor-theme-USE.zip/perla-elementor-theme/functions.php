<?php
/**
 * Perla Desjardins — Elementor theme functions
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

define( 'PERLA_THEME_VERSION', '1.0' );
define( 'PERLA_THEME_DIR', get_template_directory() );
define( 'PERLA_THEME_URI', get_template_directory_uri() );

/**
 * Enqueue styles and scripts
 */
function perla_scripts() {
  $ver = PERLA_THEME_VERSION;
  wp_enqueue_style(
    'perla-google-fonts',
    'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400&family=Outfit:wght@300;400;500&display=swap',
    array(),
    null
  );
  wp_enqueue_style(
    'perla-base',
    PERLA_THEME_URI . '/assets/css/style.css',
    array(),
    $ver
  );
  wp_enqueue_style(
    'perla-pages',
    PERLA_THEME_URI . '/assets/css/pages.css',
    array( 'perla-base' ),
    $ver
  );
  wp_enqueue_script(
    'perla-main',
    PERLA_THEME_URI . '/assets/js/main.js',
    array(),
    $ver,
    true
  );
}
add_action( 'wp_enqueue_scripts', 'perla_scripts' );

/**
 * Instagram embed on front page
 */
function perla_instagram_embed() {
  if ( is_front_page() ) {
    wp_enqueue_script(
      'instagram-embed',
      '//www.instagram.com/embed.js',
      array(),
      null,
      true
    );
    wp_script_add_data( 'instagram-embed', 'async', true );
  }
}
add_action( 'wp_enqueue_scripts', 'perla_instagram_embed', 20 );

/**
 * Theme setup
 */
function perla_setup() {
  add_theme_support( 'title-tag' );
  add_theme_support( 'post-thumbnails' );
  add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
  add_theme_support( 'custom-logo', array(
    'height'      => 80,
    'width'       => 240,
    'flex-height' => true,
    'flex-width'  => true,
  ) );
  add_theme_support( 'elementor' );
  add_theme_support( 'elementor-header-footer' );
  add_theme_support( 'responsive-embeds' );

  register_nav_menus( array(
    'primary' => __( 'Primary (header)', 'perla-elementor' ),
    'footer'  => __( 'Footer', 'perla-elementor' ),
  ) );
}
add_action( 'after_setup_theme', 'perla_setup' );

/**
 * Fallback if no menu assigned: show pages
 */
function perla_primary_menu_fallback() {
  echo '<ul class="nav-list">';
  echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">Home</a></li>';
  wp_list_pages( array(
    'title_li' => '',
    'depth'    => 1,
    'exclude'  => get_option( 'page_on_front' ),
  ) );
  echo '<li><a href="https://linktr.ee/perladesjardins#collection-47b9d1f6-8636-4691-8537-333f3510b69c" target="_blank" rel="noopener noreferrer">Shop</a></li>';
  echo '</ul>';
}

/**
 * Body class for current page (active nav)
 */
function perla_body_class( $classes ) {
  if ( is_front_page() ) {
    $classes[] = 'page-home';
  }
  return $classes;
}
add_filter( 'body_class', 'perla_body_class' );
