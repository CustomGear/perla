</main>
<footer class="site-footer">
  <div class="container">
    <div class="footer-nav-wrap">
      <?php
      if ( has_nav_menu( 'footer' ) ) {
        wp_nav_menu( array(
          'theme_location' => 'footer',
          'container'      => false,
          'menu_class'     => 'footer-links',
        ) );
      } else {
        echo '<div class="footer-links">';
        echo '<a href="' . esc_url( home_url( '/about' ) ) . '">About</a>';
        echo '<a href="' . esc_url( home_url( '/gallery' ) ) . '">Gallery</a>';
        echo '<a href="' . esc_url( home_url( '/services' ) ) . '">Services</a>';
        echo '<a href="' . esc_url( home_url( '/work-with-me' ) ) . '">Work with me</a>';
        echo '</div>';
      }
      ?>
      <div class="footer-legal">
        <?php
        $privacy = get_page_by_path( 'privacy-policy' );
        $faq    = get_page_by_path( 'faq' );
        if ( $privacy ) {
          echo '<a href="' . esc_url( get_permalink( $privacy ) ) . '">' . esc_html__( 'Privacy Policy', 'perla-elementor' ) . '</a>';
        } else {
          echo '<a href="' . esc_url( home_url( '/privacy-policy' ) ) . '">' . esc_html__( 'Privacy Policy', 'perla-elementor' ) . '</a>';
        }
        if ( $faq ) {
          echo ' <a href="' . esc_url( get_permalink( $faq ) ) . '">FAQ</a>';
        } else {
          echo ' <a href="' . esc_url( home_url( '/faq' ) ) . '">FAQ</a>';
        }
        ?>
      </div>
    </div>
    <div class="footer-socials">
      <a href="https://www.instagram.com/perla.desjardins/" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
      </a>
      <a href="https://www.tiktok.com/@perla.desjardins" target="_blank" rel="noopener noreferrer" aria-label="TikTok">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/></svg>
      </a>
      <a href="https://www.youtube.com/@perladesjardins" target="_blank" rel="noopener noreferrer" aria-label="YouTube">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
      </a>
      <a href="https://linktr.ee/perladesjardins" target="_blank" rel="noopener noreferrer" aria-label="Linktree">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" fill="none" aria-hidden="true"><path d="M226.993 168.546L173.931 114L143.128 145.546L198.786 198.607H120.499V242.395H199.157L143.128 296.822L173.931 327.745L249.993 251.312L326.055 327.745L356.859 296.941L300.829 242.515H379.501V198.607H301.214L356.872 145.546L326.069 114L273.007 168.546V91H226.993V168.546ZM273.007 305.102H226.993V409H273.007V305.102Z" fill="currentColor"/></svg>
      </a>
    </div>
    <p class="footer-copy">&copy; <?php echo esc_html( date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. UGC Creator Portfolio.</p>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
